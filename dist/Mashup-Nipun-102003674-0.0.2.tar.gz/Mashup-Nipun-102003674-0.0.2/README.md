# Mashup-Python

**Assignment-2**


Submitted By: **Nipun Garg**

***

## Description
Video to Audio Conversion

## In Command Prompt
```
pip install Mashup-Nipun-102003674
```

```
python 102003674.py "Diljit Dosanjh" 20 20 102003674-output.mp3
```
